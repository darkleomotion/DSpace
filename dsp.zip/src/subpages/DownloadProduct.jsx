import React, { useState } from "react";
import Icon from "../assets/icon.png";

const DownloadProduct = ({ view, setViewItem, pur, setPurItem }) => {
  if (view !== "") {
    return (
      <div className="grid-bar">
        <div className="empty-card cvs">
          <div className="cntr">
            <div className="body-bar">
              <div className="title">
                <h4>Sonata&reg;</h4>
                <div className="icon">
                  <img src={Icon} alt="" />
                </div>
              </div>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi,
                atque. Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                Sapiente, veritatis.
              </p>
              <p>
                <span>Tags :</span> Tags
              </p>
              <p>
                <span>Size :</span> 56 MB
              </p>
              <p>
                <span>OS Version :</span> Windows / Mac
              </p>
              <p>
                <span>Req RAM :</span> 4 GB
              </p>
              <p>
                <span>Req V.RAM :</span> 128 MB
              </p>
              <p>
                <span>Version :</span> 8.1.1.5
              </p>
              <div className="btn-bar">
                <div className="btn-bx yes">
                  <i className="fa fa-download"></i>
                  get
                </div>

                <div className="btn-bx">
                  <i className="fa fa-link"></i>
                  Share
                </div>
                <div
                  className="btn-bx close"
                  onClick={() => {
                    setViewItem("");
                  }}
                >
                  <i className="fa fa-close"></i>
                  close
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  if (pur !== "") {
    return (
      <div className="grid-bar">
        <div className="empty-card cvs">
          <div className="cntr">
            <div className="body-bar">
              <div className="title">
                <h4>Sonata&reg;</h4>
                <div className="icon">
                  <img src={Icon} alt="" />
                </div>
              </div>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi,
                atque. Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                Sapiente, veritatis.
              </p>
              <p>
                <span>Tags :</span> Tags
              </p>
              <p>
                <span>Size :</span> 56 MB
              </p>
              <p>
                <span>OS Version :</span> Windows / Mac
              </p>
              <p>
                <span>Req RAM :</span> 4 GB
              </p>
              <p>
                <span>Req V.RAM :</span> 128 MB
              </p>
              <p>
                <span>Version :</span> 8.1.1.5
              </p>
              <div className="btn-bar">
                <div className="btn-bx yes">
                  <i className="fa fa-shopping-cart"></i>
                  Buy
                </div>

                <div className="btn-bx">
                  <i className="fa fa-link"></i>
                  Share
                </div>
                <div
                  className="btn-bx close"
                  onClick={() => {
                    setPurItem("");
                  }}
                >
                  <i className="fa fa-close"></i>
                  close
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
};

export default DownloadProduct;
