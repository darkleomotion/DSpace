import React from "react";
import { Link } from "react-router-dom";
import Footer from "../pages/Footer";
import Img from "../assets/duruthu.png";

const ReadNews = () => {
  return (
    <div className="flow-wall">
      <div className="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/news_area"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <div class="textline">
            <h2>Article</h2>
          </div>

          <i class="fa fa-newspaper"></i>
        </div>
        <div className="news-wall">
          <div className="news-img">
            <img src={Img} alt="" />
          </div>
          <div className="news-title">
            <h4>Title text</h4>
          </div>
          <div className="news-text">
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis
              rerum voluptates est doloremque ratione aspernatur libero, maxime
              omnis, neque voluptatem quam, cumque aliquam beatae perferendis
              non rem illum ullam iure ab tempora. Voluptas modi impedit quos
              alias ducimus tempora tenetur. Ad, asperiores consequatur.
              Expedita at earum eos esse, temporibus fugit?
              <br />
              <br />
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis
              rerum voluptates est doloremque ratione aspernatur libero, maxime
              omnis, neque voluptatem quam, cumque aliquam beatae perferendis
              non rem illum ullam iure ab tempora. Voluptas modi impedit quos
              alias ducimus tempora tenetur. Ad, asperiores consequatur.
              Expedita at earum eos esse, temporibus fugit?
            </p>
          </div>
          <div className="line-bar">
            <div className="line-back"></div>
            <div
              className="line"
              style={{ width: "100%", justifyContent: "center" }}
            >
              <div className="btn-wrap" onClick={() => {}}>
                <div className="btn">
                  <i class="fa fa-thumbs-up"></i>
                </div>
              </div>

              <div className="btn-wrap" onClick={() => {}}>
                <div className="btn">
                  <i class="fa fa-thumbs-down fa-flip-horizontal"></i>
                </div>
              </div>
              <div className="btn-wrap" onClick={() => {}}>
                <div className="btn">
                  <i class="fa fa-link "></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tags-bar">
          <ul>
            <li>
              <i class="fa fa-tag"></i>Audios
            </li>
            <li>
              <i class="fa fa-tag"></i>Videos
            </li>
            <li>
              <i class="fa fa-tag"></i>Quotes
            </li>
            <li>
              <i class="fa fa-tag"></i>Graphics
            </li>
            <li>
              <i class="fa fa-tag"></i>Web Templates
            </li>
          </ul>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default ReadNews;
