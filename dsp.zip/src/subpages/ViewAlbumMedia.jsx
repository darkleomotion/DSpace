import React from "react";

const ViewAlbumMedia = ({ icon, show, setview, setCategory }) => {
  let ar = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  return (
    <div className="photo-bar">
      {ar.map((key) => {
        return (
          <div
            className="photo-card"
            key={key}
            onClick={() => {
              setview("1");
              setCategory("image");
            }}
          >
            <div className="image">
              <img src={icon} alt="" />
            </div>
          </div>
        );
      })}
    </div>
  );
};
export default ViewAlbumMedia;
