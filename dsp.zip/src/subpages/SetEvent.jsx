import React, { useEffect, useState } from "react";
import Footer from "../pages/Footer";
import { Link } from "react-router-dom";

const SetEvent = ({
  setmode,
  setError,
  setErrorTime,
  setErrorActions,
  setErrorMessage,
  setErrorTitle,
  act,
}) => {
  const [action, setAction] = useState(act);
  const [title, setTitle] = useState("");
  const [email, setEmail] = useState("");
  const [details, setDetails] = useState("");
  const [date, setDate] = useState("");
  const [name, setName] = useState("");
  const [f_stage, setF_stage] = useState(false);
  const [s_stage, setS_stage] = useState(false);

  const MsgShow = (mode, error, time, actions, message, title, setAction) => {
    setError(error);
    setErrorActions(actions);
    setErrorTime(time);
    setErrorMessage(message);
    setErrorTitle(title);
    setmode(mode);
  };

  const saveData = () => {
    //data base upload
    setEmail("");
    setTitle("");
    setName("");
    setDetails("");
    setDate("");
    setAction("");
    setF_stage(false);
    setS_stage(false);
    MsgShow(
      "success",
      "success",
      5000,
      "ok",
      "Your event has been recorded successfully.",
      "Action completed"
    );
    document.getElementById("myForm").reset();
    console.log("action completed");
  };

  const resetForm = () => {
    setEmail("");
    setTitle("");
    setName("");
    setDetails("");
    setDate("");
    setAction("");
    setF_stage(false);
    setS_stage(false);
    MsgShow(
      "error",
      "warning",
      5000,
      "ok",
      "Your event is not recorded.",
      "Action Aborted"
    );
    document.getElementById("myForm").reset();
    console.log("action aborted");
  };

  useEffect(() => {
    if (act === "accept") {
      saveData();
    }
    if (act === "yes") {
      saveData();
    }
    if (act === "no") {
      resetForm();
    }
    if (act === "reject") {
      resetForm();
    }
  });

  return (
    <div className="flow-wall">
      <div className="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/events"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>

          <div class="textline">
            <h2>Set Event</h2>
          </div>
          <i class="fa fa-clock"></i>
        </div>
        <div className="post">
          {f_stage === true ? (
            <form action="" method="post" id="myForm">
              <div class="logo">
                <img src="DLM.png" alt="Logo" />
              </div>
              <p>Tell us about it breifly</p>
              <div class="flex-bar">
                <div class="input txta">
                  <i class="fa fa-flash"></i>
                  <textarea
                    name="details"
                    id="details"
                    placeholder="Tell us your wish short & sweet."
                    onChange={(e) => {
                      setDetails(e.target.value);
                    }}
                  />
                </div>
              </div>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-user"></i>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    placeholder="Your Name"
                    onChange={(e) => {
                      setName(e.target.value);
                    }}
                    required
                  />
                </div>
              </div>
              <p>Please select a date if already planned.</p>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-calendar"></i>
                  <input
                    type="date"
                    name="date"
                    id="date"
                    placeholder="Select date"
                    onChange={(e) => {
                      setDate(e.target.value);
                    }}
                    required
                  />
                </div>
              </div>

              <div class="btn-bar">
                <div
                  class="btn-bx yes"
                  onClick={() => {
                    if (details.length > 0) {
                      if (name.length > 0) {
                        if (date.length > 0) {
                          setS_stage(true);
                        } else {
                          MsgShow(
                            "success",
                            "question",
                            50,
                            "yesnoclose",
                            "Are you want to make this event without a date?",
                            "Date is not given"
                          );
                        }
                      } else {
                        MsgShow(
                          "error",
                          "warning",
                          2500,
                          "close",
                          "There is a problem with your Name!",
                          "Oops..."
                        );
                      }
                    } else {
                      MsgShow(
                        "error",
                        "warning",
                        2500,
                        "close",
                        "There is a problem with your details!",
                        "Oops..."
                      );
                    }
                  }}
                >
                  <i class="fa fa-chevron-right"></i> Proceed
                </div>
              </div>
            </form>
          ) : (
            <form action="" method="post" id="myForm">
              <div class="logo">
                <img src="DLM.png" alt="Logo" />
              </div>
              <p>Please Enter the title and your Email</p>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-question"></i>
                  <input
                    type="text"
                    name="title"
                    id="title"
                    onChange={(e) => {
                      setTitle(e.target.value);
                    }}
                    placeholder="What do you want from us?"
                    required
                  />
                </div>
              </div>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-at"></i>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    placeholder="Your email"
                    onChange={(e) => {
                      setEmail(e.target.value);
                    }}
                    required
                  />
                </div>
              </div>

              <div class="btn-bar">
                <div
                  class="btn-bx yes"
                  onClick={() => {
                    if (title.length > 3) {
                      if (email.length > 10) {
                        setF_stage(true);
                        document.getElementById("myForm").reset();
                      } else {
                        MsgShow(
                          "error",
                          "warning",
                          2500,
                          "close",
                          "There is a problem with your Email. Please change your Email",
                          "Wrong Email Address"
                        );
                      }
                    } else {
                      MsgShow(
                        "error",
                        "warning",
                        2500,
                        "close",
                        "Please answer our question first! Otherwise it's very hard to \nco-operate.",
                        "Give us more info"
                      );
                    }
                  }}
                >
                  <i class="fa fa-chevron-right"></i> Proceed
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default SetEvent;
