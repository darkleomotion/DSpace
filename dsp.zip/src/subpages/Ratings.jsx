import React, { useEffect, useState } from "react";
import Footer from "../pages/Footer";
import { Link } from "react-router-dom";

const Ratings = ({
  setmode,
  setError,
  setErrorTime,
  setErrorActions,
  setErrorMessage,
  setErrorTitle,
}) => {
  const [rate, setRate] = useState(0);
  const MsgShow = (mode, error, time, actions, message, title, setAction) => {
    setError(error);
    setErrorActions(actions);
    setErrorTime(time);
    setErrorMessage(message);
    setErrorTitle(title);
    setmode(mode);
  };
  useEffect(() => {
    let star1 = document.getElementById("star1");
    let star2 = document.getElementById("star2");
    let star3 = document.getElementById("star3");
    let star4 = document.getElementById("star4");
    let star5 = document.getElementById("star5");

    if (rate >= 1) {
      star1.classList.add("rated");
    } else {
      star1.classList.remove("rated");
    }
    if (rate >= 2) {
      star2.classList.add("rated");
    } else {
      star2.classList.remove("rated");
    }
    if (rate >= 3) {
      star3.classList.add("rated");
    } else {
      star3.classList.remove("rated");
    }
    if (rate >= 4) {
      star4.classList.add("rated");
    } else {
      star4.classList.remove("rated");
    }
    if (rate >= 5) {
      star5.classList.add("rated");
    } else {
      star5.classList.remove("rated");
    }
  }, [rate]);
  return (
    <div className="flow-wall">
      <div className="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/explore"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <div class="textline">
            <h2>Ratings</h2>
          </div>

          <i class="fa fa-star"></i>
        </div>
        <div className="post">
          <div className="logo">
            <img src="DLM.png" alt="" />
          </div>
          <h4>Rate us.</h4>
          <div className="rate-stars">
            <div
              className="star"
              id="star5"
              onClick={() => {
                setRate(5);
                MsgShow(
                  "success",
                  "success",
                  50,
                  "ok",
                  "Thanks for your 05 stars rate. You can always change your ratings as your user experiance.",
                  "Ratings Recorded"
                );
              }}
            >
              <i className="fa fa-star"></i>
            </div>
            <div
              className="star"
              id="star4"
              onClick={() => {
                setRate(4);
                MsgShow(
                  "success",
                  "success",
                  50,
                  "ok",
                  "Thanks for your 04 stars rate. You can always change your ratings as your user experiance. We are so sad about lossing a star.",
                  "Ratings Recorded"
                );
              }}
            >
              <i className="fa fa-star"></i>
            </div>
            <div
              className="star"
              id="star3"
              onClick={() => {
                setRate(3);
                MsgShow(
                  "success",
                  "success",
                  50,
                  "ok",
                  "Thanks for your 03 stars rate. You can always change your ratings as your user experiance. We are so sad about lossing 02 stars.",
                  "Ratings Recorded"
                );
              }}
            >
              <i className="fa fa-star"></i>
            </div>
            <div
              className="star"
              id="star2"
              onClick={() => {
                setRate(2);
                MsgShow(
                  "success",
                  "success",
                  50,
                  "ok",
                  "Thanks for your 02 stars rate. You can always change your ratings as your user experiance. We are so sad about lossing 03 stars.",
                  "Ratings Recorded"
                );
              }}
            >
              <i className="fa fa-star"></i>
            </div>
            <div
              className="star"
              id="star1"
              onClick={() => {
                setRate(1);
                MsgShow(
                  "success",
                  "success",
                  50,
                  "ok",
                  "Thanks for your 01 stars rate. You can always change your ratings as your user experiance. We are so sad about lossing 04 stars.",
                  "Ratings Recorded"
                );
              }}
            >
              <i className="fa fa-star"></i>
            </div>
          </div>
          <p>
            You gave us <span> 0{rate} </span> {rate > 1 ? "stars" : "star"}.
          </p>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default Ratings;
