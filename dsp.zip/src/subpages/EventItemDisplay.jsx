import React from "react";

const EventItemDisplay = ({ Icon, setViewItem, setShare }) => {
  return (
    <div className="grid-bar">
      <div className="empty-card cvs">
        <div className="cntr">
          <div className="body-bar">
            <div className="title">
              <div className="icon">
                <img src={Icon} alt="" />
              </div>
            </div>
            <p>
              <h4>@DarkLeo</h4>
            </p>
            <p>
              <span>Date :</span> 2025.01.12
            </p>
            <p>
              <span>Details :</span> Lorem ipsum dolor sit amet, consectetur
              adipisicing elit. Sequi, atque. Lorem ipsum dolor sit, amet
              consectetur adipisicing elit. Sapiente, veritatis.
            </p>
            <p>
              <span>Email :</span> s********@gmail.com
            </p>
            <div className="btn-bar">
              <div
                className="btn-bx"
                onClick={() => {
                  setShare("https://www.dspace.lk/view_events?id=" + "1");
                }}
              >
                <i className="fa fa-link"></i>
                Share
              </div>
              <div
                className="btn-bx close"
                onClick={() => {
                  setViewItem("");
                }}
              >
                <i className="fa fa-close"></i>
                close
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventItemDisplay;
