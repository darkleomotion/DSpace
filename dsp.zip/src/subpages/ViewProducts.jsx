import React, { useEffect, useState } from "react";
import Footer from "../pages/Footer";
import Icon from "../assets/icon.png";
import { Link } from "react-router-dom";
import DownloadProduct from "./DownloadProduct";

const ViewProducts = () => {
  useEffect(() => {
    if (localStorage.getItem("dsp-theme") === true) {
      document.getElementById("theme").click();
    }
  }, []);

  const [products, setProducts] = useState([]);
  const [viewItem, setViewItem] = useState("");
  return (
    <div class="flow-wall">
      <div class="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/products"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <div class="textline">
            <h2>Free Products</h2>
          </div>
          <i class="fa fa-briefcase"></i>
        </div>

        {viewItem !== "" ? (
          <DownloadProduct view={viewItem} setViewItem={setViewItem} />
        ) : null}
        <div className="search-bar">
          <div className="input">
            <div className="icon">
              <i className="fa fa-search"></i>
            </div>
            <input
              type="search"
              name="search"
              id="search"
              placeholder="Search anything here..."
            />
            <div className="srch-btn">
              <i className="fa fa-search"></i>
              <p>Search</p>
            </div>
          </div>
        </div>
        <div className="grid-bar">
          <div
            className="grid-card"
            onClick={() => {
              setViewItem("1");
            }}
          >
            <div className="image">
              <img src={Icon} alt="" />
            </div>
            <div className="text-panel">
              <h4>Sonata&reg;</h4>
              <p>Time management software</p>
            </div>
          </div>
        </div>
        <div class="body-txt">
          <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident
            temporibus dignissimos ullam exercitationem, itaque eum quis
            eligendi incidunt quas deserunt minima ut et quos. Atque explicabo
            deleniti repudiandae maxime fugiat, quisquam exercitationem
            perspiciatis optio quis dolores aut, illo nostrum quae esse autem?
            Deleniti magnam impedit consequuntur distinctio expedita voluptate
            reprehenderit.
          </p>
        </div>
        <div class="tags-bar">
          <ul>
            <li>
              <i class="fa fa-tag"></i>News
            </li>
            <li>
              <i class="fa fa-tag"></i>dspace
            </li>
            <li>
              <i class="fa fa-tag"></i>about
            </li>
            <li>
              <i class="fa fa-tag"></i>blog
            </li>
            <li>
              <i class="fa fa-tag"></i>explore
            </li>
          </ul>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default ViewProducts;
