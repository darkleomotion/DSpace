import React, { useState } from "react";
import Footer from "../pages/Footer";
import Icon from "../assets/duruthu.png";
import { Link } from "react-router-dom";
import ViewAlbumMedia from "./ViewAlbumMedia";
import ViewMedia from "./ViewMedia";

const Albums = () => {
  const [show, setShow] = useState("photo");
  const [album, setAlbum] = useState("");
  const [files, setFiles] = useState([]);
  const [viewFile, setViewFile] = useState("");
  const [category, setCategory] = useState("");

  return (
    <div class="flow-wall">
      <div class="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/media"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <ul className="selector">
            <li
              onLoad={() => {
                if (show === "photo") {
                  document.querySelector(".photo").classList.add("active");
                }
              }}
              className="photo active"
              onClick={() => {
                setShow("photo");
                setAlbum("");
                setViewFile("");
                setCategory("");
                document.querySelector(".photo").classList.add("active");
                document.querySelector(".video").classList.remove("active");
                document.querySelector(".audio").classList.remove("active");
                document.querySelector(".table").classList.remove("active");
              }}
            >
              <i className="fa fa-photo"></i>
            </li>
            <li
              className="video"
              onClick={() => {
                setShow("video");
                setAlbum("");
                setViewFile("");
                setCategory("");
                document.querySelector(".photo").classList.remove("active");
                document.querySelector(".video").classList.add("active");
                document.querySelector(".audio").classList.remove("active");
                document.querySelector(".table").classList.remove("active");
              }}
            >
              <i className="fa fa-film"></i>
            </li>
            <li
              className="audio"
              onClick={() => {
                setShow("audio");
                setAlbum("");
                setViewFile("");
                setCategory("");
                document.querySelector(".photo").classList.remove("active");
                document.querySelector(".video").classList.remove("active");
                document.querySelector(".audio").classList.add("active");
                document.querySelector(".table").classList.remove("active");
              }}
            >
              <i className="fa fa-headphones"></i>
            </li>
          </ul>
        </div>
        {viewFile !== "" ? (
          <ViewMedia icon={Icon} view={viewFile} category={category} />
        ) : null}
        {album !== "" ? (
          <ViewAlbumMedia
            icon={Icon}
            setCategory={setCategory}
            show={show}
            setview={setViewFile}
          />
        ) : null}
        <div className="search-bar">
          <div className="input">
            <div className="icon">
              <i className="fa fa-search"></i>
            </div>
            <input
              type="text"
              name="search"
              id="search"
              placeholder="Search anything here..."
            />
            <div className="srch-btn">
              <i className="fa fa-search"></i>
              <p>Search</p>
            </div>
          </div>
        </div>
        {show === "photo" ? (
          <div className="photo-bar">
            <div
              className="photo-card"
              onClick={() => {
                if (album === "photo") {
                  setAlbum("");
                } else {
                  setAlbum("photo");
                }
              }}
            >
              <div className="image">
                <img src={Icon} alt="" />
              </div>
              <div className="text-panel">
                <h4>Photo</h4>
              </div>
            </div>
          </div>
        ) : show === "video" ? (
          <div className="photo-bar">
            <div
              className="photo-card"
              onClick={() => {
                if (category !== "") {
                  setViewFile("");
                  setCategory("");
                } else {
                  setViewFile("1");
                  setCategory("video");
                }
              }}
            >
              <div className="image">
                <img src={Icon} alt="" />
              </div>
              <div className="text-panel">
                <h4>Piritha</h4>
              </div>
            </div>
          </div>
        ) : show === "audio" ? (
          <div className="photo-bar">
            <div
              className="photo-card"
              onClick={() => {
                if (category !== "") {
                  setViewFile("");
                  setCategory("");
                } else {
                  setViewFile("1");
                  setCategory("audio");
                }
              }}
            >
              <div className="image">
                <img src={Icon} alt="" />
              </div>
              <div className="text-panel">
                <h4>Bana</h4>
              </div>
            </div>
          </div>
        ) : null}

        <div class="body-txt">
          <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident
            temporibus dignissimos ullam exercitationem, itaque eum quis
            eligendi incidunt quas deserunt minima ut et quos. Atque explicabo
            deleniti repudiandae maxime fugiat, quisquam exercitationem
            perspiciatis optio quis dolores aut, illo nostrum quae esse autem?
            Deleniti magnam impedit consequuntur distinctio expedita voluptate
            reprehenderit.
          </p>
        </div>
        <div class="tags-bar">
          <ul>
            <li>
              <i class="fa fa-tag"></i>Audios
            </li>
            <li>
              <i class="fa fa-tag"></i>Videos
            </li>
            <li>
              <i class="fa fa-tag"></i>Quotes
            </li>
            <li>
              <i class="fa fa-tag"></i>Graphics
            </li>
            <li>
              <i class="fa fa-tag"></i>Web Templates
            </li>
          </ul>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default Albums;
