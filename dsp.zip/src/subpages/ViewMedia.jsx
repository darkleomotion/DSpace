import React, { useState } from "react";
import Video from "../assets/dd.mp4";
import Audio from "../assets/dd.mp3";

const ViewMedia = ({ view, icon, category }) => {
  return (
    <div className="media-file">
      <div className="title-bar">
        <h4>
          {category === "image" ? (
            <i className="fa fa-image"></i>
          ) : category === "video" ? (
            <i className="fa fa-film"></i>
          ) : category === "audio" ? (
            <i className="fa fa-headphones"></i>
          ) : null}
          Video Title
        </h4>
      </div>

      <div className="screen">
        {category === "image" ? (
          <div id="media" className="mrg">
            <img src={icon} alt="" />
          </div>
        ) : category === "video" ? (
          <div id="media">
            <video
              id="video"
              preload="auto"
              type="video/mp4"
              src={Video}
            ></video>
            <div className="controls">
              <div
                className="btn-cir"
                onClick={() => {
                  let video = document.getElementById("video");
                  video.play();
                }}
              >
                <i className="fa fa-play"></i>
              </div>
              <div
                className="btn-cir"
                onClick={() => {
                  let video = document.getElementById("video");
                  video.pause();
                }}
              >
                <i className="fa fa-pause"></i>
              </div>

              <div
                className="btn-cir"
                onClick={() => {
                  let video = document.getElementById("video");
                  if (video.muted === true) {
                    video.muted = false;
                  } else {
                    video.muted = true;
                  }
                }}
              >
                <i className="fa fa-volume-up"></i>
              </div>
              <div
                className="btn-cir"
                onClick={() => {
                  let elem = document.getElementById("video");

                  if (elem.requestFullscreen) {
                    elem.requestFullscreen();
                  } else if (elem.webkitRequestFullscreen) {
                    /* Safari */
                    elem.webkitRequestFullscreen();
                  } else if (elem.msRequestFullscreen) {
                    /* IE11 */
                    elem.msRequestFullscreen();
                  }
                }}
              >
                <i className="fas fa-expand"></i>
              </div>
            </div>
          </div>
        ) : category === "audio" ? (
          <div id="media">
            <div className="gram-phone">
              <div id="disk" className="disk ">
                <img src={icon} alt="" />
              </div>
            </div>
            <div
              className="album-art"
              style={{
                backgroundImage: `url(${icon})`,
              }}
            ></div>
            <audio
              id="audio"
              preload="auto"
              type="audio/mp3"
              src={Audio}
              onEnded={() => {
                let spin = document.getElementById("disk");
                spin.classList.remove("fa-spin");
              }}
            ></audio>
            <div className="controls">
              <div
                className="btn-cir"
                onClick={() => {
                  let video = document.getElementById("audio");
                  video.play();
                  let spin = document.getElementById("disk");
                  spin.classList.add("fa-spin");
                }}
              >
                <i className="fa fa-play"></i>
              </div>
              <div
                className="btn-cir"
                onClick={() => {
                  let video = document.getElementById("audio");
                  video.pause();
                  let spin = document.getElementById("disk");
                  spin.classList.remove("fa-spin");
                }}
              >
                <i className="fa fa-pause"></i>
              </div>

              <div
                className="btn-cir"
                onClick={() => {
                  let video = document.getElementById("audio");
                  if (video.muted === true) {
                    video.muted = false;
                  } else {
                    video.muted = true;
                  }
                }}
              >
                <i className="fa fa-volume-up"></i>
              </div>
            </div>
          </div>
        ) : null}
      </div>
      <div className="buttons">
        <div className="btn-cir">
          <i className="fa fa-chevron-left"></i>
        </div>
        <div className="flex">
          <div className="btn-cir">
            <i className="fa fa-download"></i>
          </div>
          <div className="btn-cir">
            <i className="fa fa-share"></i>
          </div>
          <div className="btn-cir">
            <i className="fa fa-bookmark"></i>
          </div>
          <div className="btn-cir">
            <i className="fa fa-star"></i>
          </div>
        </div>
        <div className="btn-cir">
          <i className="fa fa-chevron-right"></i>
        </div>
      </div>
    </div>
  );
};
export default ViewMedia;
