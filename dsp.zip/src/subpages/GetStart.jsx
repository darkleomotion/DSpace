import React, { useState } from "react";
import Footer from "../pages/Footer";
import { Link } from "react-router-dom";
import { v4 as uuidV4 } from "uuid";
import QRGenerator from "./QRGenerator";
import Scan from "../assets/scan.gif";
import Upload from "../assets/upload.gif";

function GetStart({
  setmode,
  setError,
  setErrorTime,
  setErrorActions,
  setErrorMessage,
  setErrorTitle,
  act,
  setAction,
}) {
  const [mode, setMode] = useState("send");
  const [Pastetext, setPastetext] = useState("");
  const [files, setFiles] = useState([]);
  const [key, setKey] = useState(uuidV4());
  const [Dkey, setDkey] = useState("");
  const [Password, setPassword] = useState("");

  document.addEventListener("keydown", function (event) {
    if (event.key === "Backspace") {
      setPastetext("");
    }
  });
  const MsgShow = (mode, error, time, actions, message, title, setAction) => {
    setError(error);
    setErrorActions(actions);
    setErrorTime(time);
    setErrorMessage(message);
    setErrorTitle(title);
    setmode(mode);
  };

  let passLabel = document.getElementById("checkpass");
  if (document.getElementById("checkpass")) {
    passLabel.classList.remove("fa-check");
    passLabel.classList.add("fa-close");
    passLabel.style.color = "orangered";
  }
  function fetchRequest(formData) {
    fetch("http://api.qrserver.com/v1/read-qr-code/", {
      method: "POST",
      body: formData,
    })
      .then((res) => res.json())
      .then((result) => {
        if (!result[0].symbol[0].data) {
          MsgShow(
            "error",
            "warning",
            5000,
            "close",
            "There is something wrong with your QR code.",
            "Fetching Error"
          );
          setDkey("");
          setFiles([]);
        } else {
          setDkey(result[0].symbol[0].data);
          setPastetext(result[0].symbol[0].data);
          MsgShow(
            "success",
            "success",
            5000,
            "ok",
            "Your QR code has been accepted and waiting for download your files.",
            "Action Completed"
          );
        }
      });
  }

  function DecodeImg(image) {
    let formData = new FormData();
    formData.append("file", image);
    fetchRequest(formData);
  }

  function getBase64(file, filename) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      if (document.getElementById("output" + filename)) {
        document
          .getElementById("output" + filename)
          .setAttribute("src", reader.result);
      }
      return reader.result;
    };
    reader.onerror = function (error) {
      console.log("Error: ", error);
    };
  }

  const setPass = () => {
    let input = document.getElementById("search");
    if (input.value.length === 8) {
      setPassword(input.value);
      MsgShow(
        "success",
        "success",
        50,
        "close",
        `Your password successfully added to the encryption data. Please writedown and give it to the users who want to get the file(s).`,
        "Password Added"
      );
    } else {
      MsgShow(
        "error",
        "warning",
        50,
        "close",
        `Your password is 'Null' or lessthan 8 characters in length. Please update your 8 characters length password.`,
        "Password Error"
      );
    }
  };

  function previewFile(e) {
    setFiles([]);
    let filesR = [...files];
    for (var i = 0; i < e.length; i++) {
      filesR.push(e[i]);
    }
    setFiles(filesR);
    MsgShow(
      "success",
      "success",
      5000,
      "ok",
      `You have added ${filesR.length} files to upload.`,
      "Action Completed"
    );
  }

  function closedownloadingProcess() {
    MsgShow(
      "success",
      "success",
      5000,
      "close",
      `Previous session has been aborted. Select a new QR Key file to begging process.`,
      "Session Aborted"
    );
    setFiles([]);
    setPastetext("");
    setDkey("");
  }

  return (
    <div className="flow-wall">
      <div className="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/home"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <div class="textline">
            <h2>Get Start</h2>
          </div>
          {mode === "send" ? (
            <i class="fa fa-send"></i>
          ) : (
            <i class="fa fa-qrcode"></i>
          )}
        </div>

        <div className="line-bar">
          <div className="line-back"></div>
          <div className="text-a bgtext">
            <h4 style={{ textTransform: "capitalize" }}>
              {mode === "send" ? (
                <i class="fa fa-send"></i>
              ) : (
                <i class="fa fa-qrcode"></i>
              )}
              {mode}
            </h4>
          </div>
          {mode === "send" ? (
            <div className="line">
              {Password.length === 8 ? (
                <div
                  className="btn-wrap"
                  onClick={() => {
                    document.getElementById("upload").click();
                  }}
                >
                  <div className="btn">
                    <i class="fa fa-plus"></i>
                  </div>
                </div>
              ) : (
                <div className="btn-wrap" onClick={setPass}>
                  <div className="btn">
                    <i class="fa fa-key"></i>
                  </div>
                </div>
              )}
              {files.length > 0 ? (
                <div className="btn-wrap">
                  <div className="btn">
                    <i class="fa fa-save"></i>
                  </div>
                </div>
              ) : null}
              {files.length > 0 ? (
                <div
                  className="btn-wrap"
                  onClick={() => {
                    MsgShow(
                      "success",
                      "success",
                      5000,
                      "close",
                      `Your process has been canceled. Let's begging another process. Remember?, Set a password first.`,
                      "Session Closed"
                    );
                    setFiles([]);
                    setPassword("");
                    setKey(uuidV4());
                  }}
                >
                  <div className="btn">
                    <i class="fa fa-repeat"></i>
                  </div>
                </div>
              ) : null}

              <div
                className="btn-wrap"
                onClick={() => {
                  setMode("recieve");
                  setDkey("");
                  setPassword("");
                  setFiles([]);
                }}
              >
                <div className="btn">
                  <i class="fa fa-qrcode"></i>
                </div>
              </div>
            </div>
          ) : mode === "recieve" ? (
            <div className="line">
              {Dkey.length > 0 ? (
                <>
                  <div
                    className="btn-wrap"
                    onClick={() => {
                      //document.getElementById("upload").click();
                    }}
                  >
                    <div className="btn">
                      <i class="fa fa-archive"></i>
                    </div>
                  </div>
                  <div
                    className="btn-wrap"
                    onClick={() => {
                      //document.getElementById("upload").click();
                    }}
                  >
                    <div className="btn">
                      <i class="fa fa-download"></i>
                    </div>
                  </div>
                  <div
                    className="btn-wrap"
                    onClick={() => {
                      closedownloadingProcess();
                    }}
                  >
                    <div className="btn">
                      <i class="fa fa-repeat"></i>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div
                    className="btn-wrap"
                    onClick={() => {
                      document.getElementById("upload").click();
                    }}
                  >
                    <div className="btn">
                      <i class="fa fa-camera"></i>
                    </div>
                  </div>
                  <div
                    className="btn-wrap"
                    onClick={() => {
                      document.getElementById("upload").click();
                    }}
                  >
                    <div className="btn">
                      <i class="fa fa-image"></i>
                    </div>
                  </div>
                  <div
                    className="btn-wrap"
                    onClick={() => {
                      document.getElementById("search").click();
                    }}
                  >
                    <div className="btn">
                      <i class="fa fa-brush"></i>
                    </div>
                  </div>
                </>
              )}
              <div
                className="btn-wrap"
                onClick={() => {
                  setPastetext("");
                  setMode("send");
                  setDkey("");
                  setKey(uuidV4());
                  setFiles([]);
                }}
              >
                <div className="btn">
                  <i class="fa fa-send"></i>
                </div>
              </div>
            </div>
          ) : null}
        </div>
        {files.length > 0 ? (
          <div class="body-center">
            <h4>Your Key : </h4>
            <QRGenerator keyNo={key} setKn={setKey} />
          </div>
        ) : null}
        {mode === "send" ? (
          <>
            {Password.length < 8 ? (
              <div className="paste-bar">
                <div className="paste-put auto">
                  <div className="icon">
                    <i className="fa fa-key"></i>
                  </div>
                  <input
                    type="password"
                    name="link-address"
                    id="search"
                    className="pss"
                    maxLength={8}
                    placeholder="________"
                    onChange={(e) => {
                      if (e.target.value.length <= 7) {
                        passLabel.classList.remove("fa-check");
                        passLabel.classList.add("fa-close");
                        passLabel.style.color = "orangered";
                      } else {
                        passLabel.classList.remove("fa-close");
                        passLabel.classList.add("fa-check");
                        passLabel.style.color = "green";
                      }
                    }}
                  />
                  <div className="icon">
                    <i className="fa fa-check" id="checkpass"></i>
                  </div>
                </div>
              </div>
            ) : null}
            {files.length > 0 ? (
              <div className="grid-bar">
                {files.map((file) => {
                  let type = file.type;
                  return (
                    <div className="grid-card" key={file.name}>
                      <div className="image">
                        {file.type.includes("image") ? (
                          <i className="fa fa-image"></i>
                        ) : file.type.includes("audio") ? (
                          <i className="fa fa-headphones"></i>
                        ) : file.type.includes("json") ? (
                          <i className="fa fa-code"></i>
                        ) : file.type.includes("text") ? (
                          <i className="fa fa-list"></i>
                        ) : file.type.includes("video") ? (
                          <i className="fa fa-film"></i>
                        ) : file.type.includes("zip") ? (
                          <i className="fa fa-archive"></i>
                        ) : file.name.includes(".rar") ? (
                          <i className="fa fa-archive"></i>
                        ) : (
                          <i className="fa fa-warning"></i>
                        )}
                      </div>
                      <div className="text-panel">
                        <h4>
                          {file.name.length > 15
                            ? file.name.substring(0, 15) + "..."
                            : file.name}
                        </h4>
                        <p>{Math.round(file.size / 1024) + " KB"}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="grid-bar center-bar">
                <div className="empty-card">
                  <div className="btn-bar">
                    <div className="cover">
                      <img src={Upload} alt="" srcset="" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            <input
              type="file"
              name="upload"
              id="upload"
              multiple
              onChange={(e) => {
                if (e.target.files) {
                  previewFile(e.target.files);
                  e.target.value = "";
                }
              }}
            />
          </>
        ) : (
          <>
            {Dkey.length > 0 ? (
              <div class="body-center">
                <h4>Your Downloads Ready </h4>
                <QRGenerator keyNo={Dkey} setKn={setKey} />
              </div>
            ) : null}
            {mode === "recieve" ? (
              <div className="paste-bar">
                <div className="paste-put">
                  <div className="icon">
                    <i className="fa fa-paste"></i>
                  </div>
                  <input
                    type="text"
                    name="link-address"
                    id="search"
                    placeholder="Paste your key here..."
                    value={Pastetext.length > 0 ? Pastetext : ""}
                    onClick={(e) => {
                      setTimeout(async () => {
                        const text = await navigator.clipboard.readText();
                        if (
                          text.includes("https://www.dspace.lk/get_file?id=")
                        ) {
                          setPastetext(text);
                          setDkey(text);
                          MsgShow(
                            "success",
                            "success",
                            50,
                            "ok",
                            "Your key has been captured. Wait for generate your content.",
                            "Key Found"
                          );
                        } else {
                          MsgShow(
                            "error",
                            "warning",
                            50,
                            "close",
                            "No key code has found on your clipboard. Copy your key text or scan the QR Code to get your files.",
                            "No Key Found"
                          );
                          setPastetext("");
                          setDkey("");
                          setFiles([]);
                        }
                      }, 20);
                    }}
                  />
                </div>
              </div>
            ) : null}
            {files.length > 0 ? (
              <div className="grid-bar">
                {files.map((file) => {
                  return (
                    <div className="grid-card" key={file.name}>
                      <div className="image">
                        {file.type.includes("image") ? (
                          <i className="fa fa-image"></i>
                        ) : file.type.includes("audio") ? (
                          <i className="fa fa-headphones"></i>
                        ) : file.type.includes("json") ? (
                          <i className="fa fa-code"></i>
                        ) : file.type.includes("text") ? (
                          <i className="fa fa-list"></i>
                        ) : file.type.includes("video") ? (
                          <i className="fa fa-film"></i>
                        ) : file.type.includes("zip") ? (
                          <i className="fa fa-archive"></i>
                        ) : file.name.includes(".rar") ? (
                          <i className="fa fa-archive"></i>
                        ) : (
                          <i className="fa fa-warning"></i>
                        )}
                      </div>
                      <div className="text-panel">
                        <h4>{file.name}</h4>
                        <p>{Math.round(file.size / 1024)} KB</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="grid-bar center-bar">
                <div className="empty-card">
                  <div className="btn-bar">
                    <div className="cover">
                      <img src={Scan} alt="" srcset="" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            <input
              type="file"
              name="upload"
              id="upload"
              onChange={(e) => {
                if (e.target.files) {
                  DecodeImg(e.target.files[0]);
                  e.target.value = "";
                }
              }}
            />
          </>
        )}
      </div>
      <Footer />
    </div>
  );
}
export default GetStart;
