import React, { useState } from "react";
import Footer from "../pages/Footer";
import Icon from "../assets/download.gif";
import { Link } from "react-router-dom";

const DownloadMedia = ({
  setmode,
  setError,
  setErrorTime,
  setErrorActions,
  setErrorMessage,
  setErrorTitle,
  act,
  setAction,
}) => {
  const [Pastetext, setPastetext] = useState("");
  const [files, setFiles] = useState([]);
  document.addEventListener("keydown", function (event) {
    if (event.key === "Backspace") {
      setPastetext("");
    }
  });
  const MsgShow = (mode, error, time, actions, message, title, setAction) => {
    setError(error);
    setErrorActions(actions);
    setErrorTime(time);
    setErrorMessage(message);
    setErrorTitle(title);
    setmode(mode);
  };
  function fetchRequest(formData) {
    fetch("http://api.qrserver.com/v1/read-qr-code/", {
      method: "POST",
      body: formData,
    })
      .then((res) => res.json())
      .then((result) => {
        if (!result[0].symbol[0].data) {
          MsgShow(
            "error",
            "warning",
            50,
            "close",
            "No QR code has found on your image. Copy your key text or scan the correct QR Code to get your files.",
            "Wrong image format"
          );
          setPastetext("");
          document.getElementById("search").value = "";
        } else {
          let text = result[0].symbol[0].data;
          if (text.includes("download_media")) {
            setPastetext(text);
            MsgShow(
              "success",
              "success",
              50,
              "ok",
              "Your key has been captured. Wait for generate your content.",
              "Key Found"
            );
          } else {
            MsgShow(
              "error",
              "warning",
              50,
              "close",
              "No key code has found on your QR image. Copy your key text or scan the correct QR Code to get your files.",
              "No Key Found"
            );
            setPastetext("");
            document.getElementById("search").value = "";
          }
        }
      });
  }

  function DecodeImg(image) {
    let formData = new FormData();
    formData.append("file", image);
    fetchRequest(formData);
  }
  return (
    <div className="flow-wall">
      <div className="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/media"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <div class="textline">
            <h2>Download</h2>
          </div>
          <i class="fa fa-cloud-download"></i>
        </div>

        <div className="line-bar">
          <div className="line-back"></div>
          <div className="text-a bgtext">
            <h4 style={{ textTransform: "capitalize" }}>
              <i class="fa fa-image"></i>
              Photo
            </h4>
          </div>
          <div className="line">
            <div
              className="btn-wrap"
              onClick={() => {
                document.getElementById("upload").click();
              }}
            >
              <div className="btn">
                <i class="fa fa-camera"></i>
              </div>
            </div>

            <div
              className="btn-wrap"
              onClick={() => {
                document.getElementById("upload").click();
              }}
            >
              <div className="btn">
                <i class="fa fa-image"></i>
              </div>
            </div>
            <div
              className="btn-wrap"
              onClick={() => {
                document.getElementById("search").click();
              }}
            >
              <div className="btn">
                <i class="fa fa-brush"></i>
              </div>
            </div>
          </div>
        </div>
        <div className="paste-bar">
          <div className="paste-put">
            <div className="icon">
              <i className="fa fa-paste"></i>
            </div>
            <input
              type="text"
              name="link-address"
              id="search"
              placeholder="Paste Link here..."
              value={Pastetext.length > 0 ? Pastetext : null}
              onClick={(e) => {
                setTimeout(async () => {
                  const text = await navigator.clipboard.readText();
                  if (text.includes("download_media")) {
                    setPastetext(text);
                    MsgShow(
                      "success",
                      "success",
                      50,
                      "ok",
                      "Your key has been captured. Wait for generate your content.",
                      "Key Found"
                    );
                  } else {
                    MsgShow(
                      "error",
                      "warning",
                      50,
                      "close",
                      "No key code has found on your clipboard. Copy your key text or scan the QR Code to get your files.",
                      "No Key Found"
                    );
                    setPastetext("");
                  }
                }, 20);
              }}
            />
          </div>
        </div>
        <div className="grid-bar center-bar">
          <div className="empty-card">
            <div className="btn-bar">
              <div className="cover">
                <img src={Icon} alt="" srcset="" />
              </div>
            </div>
          </div>
        </div>
        <div class="body-txt">
          <p>
            Welcome to our Download Center! Here, you'll find a curated
            selection of files available for download, including software
            updates, multimedia assets, and informative resources. Each file is
            accompanied by a convenient QR code for quick and easy access on
            your mobile devices. Simply scan the code with your phone to
            instantly download the content you need.
          </p>
        </div>

        <input
          type="file"
          name="upload"
          id="upload"
          multiple
          onChange={(e) => {
            if (e.target.files) {
              DecodeImg(e.target.files[0]);
              e.target.value = "";
            }
          }}
        />
      </div>
      <Footer />
    </div>
  );
};
export default DownloadMedia;
