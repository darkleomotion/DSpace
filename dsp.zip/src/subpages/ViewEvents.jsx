import React, { useState } from "react";
import Footer from "../pages/Footer";
import Icon from "../assets/duruthu.png";
import { Link } from "react-router-dom";
import EventItemDisplay from "./EventItemDisplay";

const ViewEvents = ({ setShare }) => {
  const [show, setShow] = useState("photo");
  const [viewItem, setViewItem] = useState("");
  return (
    <div class="flow-wall">
      <div class="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/events"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <div class="textline">
            <h2>Events</h2>
          </div>
          <i class="fa fa-calendar"></i>
        </div>
        <div className="search-bar">
          <div className="input">
            <div className="icon">
              <i className="fa fa-search"></i>
            </div>
            <input
              type="text"
              name="search"
              id="search"
              placeholder="Search anything here..."
            />
            <div className="srch-btn">
              <i className="fa fa-search"></i>
              <p>Search</p>
            </div>
          </div>
        </div>
        {viewItem !== "" ? (
          <EventItemDisplay
            Icon={Icon}
            setViewItem={setViewItem}
            setShare={setShare}
          />
        ) : null}
        <div className="photo-bar">
          <div
            className="photo-card"
            onClick={() => {
              setViewItem("1");
            }}
          >
            <div className="image">
              <img src={Icon} alt="" />
            </div>
            <div className="text-panel">
              <h4>@DarkLeo</h4>
            </div>
          </div>
        </div>

        <div class="body-txt">
          <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident
            temporibus dignissimos ullam exercitationem, itaque eum quis
            eligendi incidunt quas deserunt minima ut et quos. Atque explicabo
            deleniti repudiandae maxime fugiat, quisquam exercitationem
            perspiciatis optio quis dolores aut, illo nostrum quae esse autem?
            Deleniti magnam impedit consequuntur distinctio expedita voluptate
            reprehenderit.
          </p>
        </div>
        <div class="tags-bar">
          <ul>
            <li>
              <i class="fa fa-tag"></i>Audios
            </li>
            <li>
              <i class="fa fa-tag"></i>Videos
            </li>
            <li>
              <i class="fa fa-tag"></i>Quotes
            </li>
            <li>
              <i class="fa fa-tag"></i>Graphics
            </li>
            <li>
              <i class="fa fa-tag"></i>Web Templates
            </li>
          </ul>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default ViewEvents;
