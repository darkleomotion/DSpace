import React, { useState } from "react";
import Sign from "./Sign";
import User from "./User";

function Profile({
  setmode,
  setError,
  setErrorTime,
  setErrorActions,
  setErrorMessage,
  setErrorTitle,
  login,
  setLogin,
}) {
  return (
    <>
      {localStorage.getItem("dsp-login-status") !== "true" ? (
        <Sign
          setmode={setmode}
          setError={setError}
          setErrorTime={setErrorTime}
          setErrorActions={setErrorActions}
          setErrorMessage={setErrorMessage}
          setErrorTitle={setErrorTitle}
          setLogins={setLogin}
        />
      ) : (
        <User setLogin={setLogin} login={login} />
      )}
      ;
    </>
  );
}
export default Profile;
