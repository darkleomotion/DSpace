import React, { useState } from "react";
import { v4 as uuidV4 } from "uuid";
import Footer from "./Footer";
import Author from "../assets/author.jpg";
import { Link } from "react-router-dom";

function User({ setLogin, login }) {
  const [user] = useState(() => {
    if (localStorage.getItem("dsp-user")) {
      localStorage.getItem("dsp-user");
    } else {
      localStorage.setItem("dsp-user", "User" + uuidV4().substring(0, 3));
    }
  });

  return (
    <div className="flow-wall">
      <div className="scroll-wall">
        <div class="headline">
          <Link className="back-btn" to={"/home"}>
            <i className="fa fa-chevron-circle-left"></i>
          </Link>
          <div class="textline">
            <h2>Profile</h2>
          </div>
          <i class="fa fa-user-circle"></i>
        </div>
        <div className="post">
          <div class="user">
            <div className="img">
              <img src={Author} alt="Logo" />
            </div>
          </div>
          <h4>Welcome back </h4>
          <p>{user}</p>
          <div className="btn-bar">
            <div
              className="btn-bx"
              onClick={() => {
                setLogin("false");
                localStorage.setItem("dsp-login-status", "false");
                window.location.reload();
              }}
            >
              <i className="fa fa-sign-out"></i>
              Sign out
            </div>
            <div className="btn-bx close">
              <i className="fa fa-repeat"></i>
              Reset
            </div>
            <div className="btn-bx cancel">
              <i className="fa fa-trash"></i>
              Delete
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
export default User;
