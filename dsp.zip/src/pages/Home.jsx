import React from "react";
import "../styles/body.css";
import Footer from "./Footer";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="wall">
      <div class="post">
        <div class="logo">
          <img src="DLM.png" alt="Logo" />
        </div>
        <h4>Welcome to dspace</h4>
        <p>
          At Dspace.lk, we specialize in developing cutting-edge multimedia
          services to bring your digital dreams to life. From stunning web
          designs to robust software solutions, our team of experts is dedicated
          to delivering innovative, high-quality products tailored to meet your
          unique needs. Join us on this journey to digital excellence.
        </p>
        <div class="btn-bar">
          <Link class="btn-bx" to={"/explore"}>
            <i class="fa fa-rocket"></i> Explore
          </Link>
          <Link class="btn-bx" to={"/get_start"}>
            <i class="fa fa-chevron-right"></i> Get Started
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}
export default Home;
