import React, { useState } from "react";
import Footer from "./Footer";

const ForgotPass = ({
  setmode,
  setError,
  setErrorTime,
  setErrorActions,
  setErrorMessage,
  setErrorTitle,
}) => {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [pass, setPass] = useState("");
  const [passc, setPassC] = useState("");
  const [sent, setSent] = useState(false);
  const [varified, setVarified] = useState(false);
  const [passSet, setPassSet] = useState(false);

  const MsgShow = (mode, error, time, actions, message, title, setAction) => {
    setError(error);
    setErrorActions(actions);
    setErrorTime(time);
    setErrorMessage(message);
    setErrorTitle(title);
    setmode(mode);
  };
  const ClearForm = () => {
    let form = document.getElementById("formc");
    form.reset();
  };
  return (
    <div className="wall">
      <div className="scroll-wall">
        <div className="post">
          {sent === false ? (
            <form action="" method="post" id="formc">
              <div class="logo">
                <img src="DLM.png" alt="Logo" />
              </div>
              <h4>Password Recovery</h4>
              <p>
                <br />
                Please use your following Email Address to continue.
                <br />
                <br />
                <span>Srid*****@*****.com</span>
              </p>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-at"></i>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    placeholder="Srid*****@*****.com"
                    onChange={(e) => {
                      if (e.target.value.length > 0) {
                        setEmail(e.target.value);
                      }
                    }}
                    required
                  />
                </div>
              </div>

              <div class="btn-bar">
                <div
                  class="btn-bx"
                  onClick={() => {
                    setSent(true);
                    ClearForm();
                  }}
                >
                  <i class="fa fa-send"></i> Send OTP
                </div>
              </div>
            </form>
          ) : varified === false ? (
            <form action="" method="post" id="formc">
              <div class="logo">
                <img src="DLM.png" alt="Logo" />
              </div>
              <h4>Password Recovery</h4>
              <p>
                <br />
                Please use your 6 digit OTP number.
              </p>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-key"></i>
                  <input
                    type="text"
                    name="otp"
                    maxLength={6}
                    id="username"
                    placeholder="******"
                    onChange={(e) => {
                      if (e.target.value.length > 0) {
                        setOtp(e.target.value);
                      }
                    }}
                    required
                  />
                </div>
              </div>

              <div class="btn-bar">
                <div
                  class="btn-bx"
                  onClick={() => {
                    setVarified(true);
                    ClearForm();
                  }}
                >
                  <i class="fa fa-shield"></i> Varify Account
                </div>
              </div>
            </form>
          ) : passSet === false ? (
            <form action="" method="post" id="formc">
              <div class="logo">
                <img src="DLM.png" alt="Logo" />
              </div>
              <h4>Password Recovery</h4>
              <p>
                <br />
                Set your new password.
              </p>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-key"></i>
                  <input
                    type="password"
                    name="password"
                    maxLength={16}
                    id="password"
                    placeholder="New Password"
                    onChange={(e) => {
                      if (e.target.value.length > 0) {
                        setPass(e.target.value);
                      }
                    }}
                    required
                  />
                </div>
              </div>
              <div class="flex-bar">
                <div class="input">
                  <i class="fa fa-key"></i>
                  <input
                    type="password"
                    name="password"
                    maxLength={16}
                    id="password"
                    placeholder="Confirm Password"
                    onChange={(e) => {
                      if (e.target.value.length > 0) {
                        setPassC(e.target.value);
                      }
                    }}
                    required
                  />
                </div>
              </div>

              <div class="btn-bar">
                <div
                  class="btn-bx"
                  onClick={() => {
                    MsgShow(
                      "success",
                      "success",
                      50,
                      "close",
                      "You have changed your password successfully. Feel free to use your new password in Dspace. Make a safe journey.",
                      "Password Changed"
                    );
                    ClearForm();
                    window.location.href = "/home";
                  }}
                >
                  <i class="fa fa-lock"></i> Set Password
                </div>
              </div>
            </form>
          ) : null}
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default ForgotPass;
