import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer>
      <ul>
        <li>
          <Link to={"/terms_n_conditions"}>
            <i className="fa fa-shield"></i>
          </Link>
        </li>
        <li>
          <label
            for="theme"
            onClick={() => {
              localStorage.setItem("dsp-theme", "true");
            }}
          >
            <i className="fa fa-moon moon"></i>
          </label>
          <label
            for="theme"
            onClick={() => {
              localStorage.setItem("dsp-theme", "false");
            }}
          >
            <i className="fa fa-sun sun"></i>
          </label>
        </li>
        <li>
          <Link to="/terms_n_conditions?cookie_policy=true">
            <i className="fa fa-cookie"></i>
          </Link>
        </li>
        <li className="sml">
          <a href="/copyright">
            <i className="fa fa-copyright"></i>
          </a>
        </li>
      </ul>
      <p className="big">&copy;2024 Dark Leo</p>
      <ul>
        <li>
          <a href="callto:+768463836">
            <i className="fa fa-phone"></i>
          </a>
        </li>
        <li>
          <a href="mailto:support@dspace.lk">
            <i className="fa fa-envelope"></i>
          </a>
        </li>
        <li>
          <a href="https://maps.google.com">
            <i className="fa fa-location-arrow"></i>
          </a>
        </li>
        <li>
          <a href="https://www.github.com">
            <i className="fa fa-github"></i>
          </a>
        </li>
      </ul>
    </footer>
  );
}
export default Footer;
