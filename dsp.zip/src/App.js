import "./styles/App.css";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Events from "./pages/Events";
import Media from "./pages/Media";
import Profile from "./pages/Profile";
import { Link, Route, Routes } from "react-router-dom";
import React, { useEffect, useState } from "react";
import ViewProducts from "./subpages/ViewProducts";
import PurchaseProducts from "./subpages/PurchaseProducts";
import Albums from "./subpages/Albums";
import DownloadMedia from "./subpages/DownloadMedia";
import ErrorProvider from "./pages/ErrorProvider";
import ViewEvents from "./subpages/ViewEvents";
import SetEvent from "./subpages/SetEvent";
import Background from "./subpages/Background";
import ExploreSpace from "./subpages/ExploreSpace";
import SecuritySupport from "./subpages/SecuritySupport";
import GetStart from "./subpages/GetStart";
import NewsPanel from "./subpages/NewsPanel";
import ReadNews from "./subpages/ReadNews";
import ForgotPass from "./pages/ForgotPass";
import QRshare from "./subpages/QRshare";
import Ratings from "./subpages/Ratings";

function App() {
  const [bigging, setBigging] = useState(true);
  const [Error, setError] = useState("load");
  const [ErrorTitle, setErrorTitle] = useState("Loading Dspace");
  const [ErrorTime, setErrorTime] = useState(5000);
  const [ErrorActions, setErrorActions] = useState("none");
  const [ErrorAction, setErrorAction] = useState("");
  const [ErrorMode, setErrorMode] = useState("normal");
  const [ErrorMessage, setErrorMessage] = useState(
    "Please wait few seconds..."
  );
  const [share, setShare] = useState("");
  const [login, setLogin] = useState(false);

  useEffect(() => {
    if (localStorage.getItem("dsp-login-status")) {
      setLogin(localStorage.getItem("dsp-login-status"));
      if (localStorage.getItem("login")) {
        setBigging(false);
      } else {
        localStorage.setItem("login", "signin");
      }
    } else {
      localStorage.setItem("dsp-login-status", false);
      localStorage.setItem("dsp-theme", false);
      localStorage.setItem("login", "signin");
    }

    if (localStorage.getItem("dsp-theme") === "true") {
      document.getElementById("theme").click();
    }
  }, [bigging]);
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to={"/home"}>
              <i className="fa fa-home fa-gradient"></i>
            </Link>
          </li>
          <li>
            <Link to={"/products"}>
              <i className="fa fa-rocket fa-gradient"></i>
            </Link>
          </li>
          <li>
            <Link to={"/media"}>
              <i className="fa fa-images fa-gradient"></i>
            </Link>
          </li>

          <li>
            <Link to={"/events"}>
              <i className="fa fa-trophy fa-gradient"></i>
            </Link>
          </li>
          <li>
            <Link to={"/profile"}>
              {login !== "true" ? (
                <i className="fa fa-sign-in fa-gradient"></i>
              ) : (
                <i className="fa fa-skull fa-gradient"></i>
              )}
            </Link>
          </li>
        </ul>
      </nav>
      {Error.length > 0 ? (
        <ErrorProvider
          error={Error}
          setError={setError}
          time={ErrorTime}
          title={ErrorTitle}
          actions={ErrorActions}
          setErrorTime={setErrorTime}
          setErrorAction={setErrorAction}
          message={ErrorMessage}
          mode={ErrorMode}
          setmode={setErrorMode}
        />
      ) : null}
      <Background />
      {share !== "" ? <QRshare addr={share} setShare={setShare} /> : null}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route
          path="/rate"
          element={
            <Ratings
              setmode={setErrorMode}
              setError={setError}
              setErrorTime={setErrorTime}
              setErrorActions={setErrorActions}
              setErrorMessage={setErrorMessage}
              setErrorTitle={setErrorTitle}
            />
          }
        />
        <Route path="/media" element={<Media />} />
        <Route
          path="/profile"
          element={
            <Profile
              setmode={setErrorMode}
              setError={setError}
              setErrorTime={setErrorTime}
              setErrorActions={setErrorActions}
              setErrorMessage={setErrorMessage}
              setErrorTitle={setErrorTitle}
              setLogin={setLogin}
              login={login}
            />
          }
        />
        <Route path="/events" element={<Events />} />
        <Route path="/view_products" element={<ViewProducts />} />
        <Route
          path="/terms_n_conditions"
          element={
            <SecuritySupport
              setmode={setErrorMode}
              setError={setError}
              setErrorTime={setErrorTime}
              setErrorActions={setErrorActions}
              setErrorMessage={setErrorMessage}
              setErrorTitle={setErrorTitle}
              act={ErrorAction}
            />
          }
        />
        <Route path="/purchase_products" element={<PurchaseProducts />} />
        <Route path="/view_albums" element={<Albums />} />
        <Route
          path="/forgot_password"
          element={
            <ForgotPass
              setmode={setErrorMode}
              setError={setError}
              setErrorTime={setErrorTime}
              setErrorActions={setErrorActions}
              setErrorMessage={setErrorMessage}
              setErrorTitle={setErrorTitle}
            />
          }
        />
        <Route
          path="/download_media"
          element={
            <DownloadMedia
              setmode={setErrorMode}
              setError={setError}
              setErrorTime={setErrorTime}
              setErrorActions={setErrorActions}
              setErrorMessage={setErrorMessage}
              setErrorTitle={setErrorTitle}
              act={ErrorAction}
              setAction={setErrorAction}
            />
          }
        />
        <Route
          path="/view_events"
          element={<ViewEvents setShare={setShare} />}
        />
        <Route path="/news_area" element={<NewsPanel />} />
        <Route path="/read_news" element={<ReadNews />} />
        <Route path="/explore" element={<ExploreSpace />} />
        <Route
          path="/get_start"
          element={
            <GetStart
              setmode={setErrorMode}
              setError={setError}
              setErrorTime={setErrorTime}
              setErrorActions={setErrorActions}
              setErrorMessage={setErrorMessage}
              setErrorTitle={setErrorTitle}
              act={ErrorAction}
              setAction={setErrorAction}
            />
          }
        />
        <Route
          path="/set_event"
          element={
            <SetEvent
              setmode={setErrorMode}
              setError={setError}
              setErrorTime={setErrorTime}
              setErrorActions={setErrorActions}
              setErrorMessage={setErrorMessage}
              setErrorTitle={setErrorTitle}
              act={ErrorAction}
              setAction={setErrorAction}
            />
          }
        />
      </Routes>
    </>
  );
}

export default App;
